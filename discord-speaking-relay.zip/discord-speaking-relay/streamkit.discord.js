const log = window.console.log.bind(window.console)
window.console.log = (...args) => {
  if (!args[1]) return log(...args);
  if (typeof args[1] !== 'object') return log(...args);
  let data = args[1].data
  let name = document.querySelector(`img[src*="${data.user_id}"]`)?.parentElement?.querySelector('span').innerHTML
  if (!name) return log(...args);
  data.evt = args[1].evt
  data.name = name;
  window.opener.postMessage(data, '*')
  log(data.name, data.evt)
}